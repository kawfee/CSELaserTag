#ifndef __CREDENTIALS_H__
#define __CREDENTIALS_H__

// Wifi parameters
char passphrase[] = "your_passphrase_here";
char ssid[] = "your_network_ssid_here";

#endif
